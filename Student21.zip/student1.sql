-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2020 at 08:57 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student1`
--

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

CREATE TABLE `college` (
  `College_Id` int(11) NOT NULL,
  `College_Name` char(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college`
--

INSERT INTO `college` (`College_Id`, `College_Name`) VALUES
(1, 'VSICS'),
(2, 'DAMS'),
(3, 'PSIT'),
(4, 'DAV'),
(5, 'HBTU'),
(6, 'ALLEN_HOUSE'),
(7, 'BHAGWANTI'),
(8, 'IILM'),
(9, 'AMU'),
(10, 'ICE');

-- --------------------------------------------------------

--
-- Table structure for table `college_course`
--

CREATE TABLE `college_course` (
  `ccrs_id` int(11) NOT NULL,
  `ccrs_clid` int(11) NOT NULL,
  `ccrs_crsid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `college_course`
--

INSERT INTO `college_course` (`ccrs_id`, `ccrs_clid`, `ccrs_crsid`) VALUES
(4, 1, 1),
(5, 1, 2),
(6, 1, 3),
(7, 2, 1),
(8, 2, 2),
(9, 2, 3),
(10, 2, 4),
(11, 2, 5),
(12, 1, 1),
(13, 1, 2),
(14, 1, 3),
(15, 1, 4),
(16, 5, 3),
(17, 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `Course_Id` int(11) NOT NULL,
  `Course_Name` char(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`Course_Id`, `Course_Name`) VALUES
(1, 'BBA'),
(2, 'BCA'),
(3, 'MBA'),
(4, 'MCA'),
(5, 'BTECH');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `usr_id` int(11) NOT NULL,
  `usr_name` varchar(100) COLLATE utf8_bin NOT NULL,
  `usr_email` varchar(100) COLLATE utf8_bin NOT NULL,
  `usr_mobile` varchar(12) COLLATE utf8_bin NOT NULL,
  `usr_clid` int(11) NOT NULL,
  `usr_crsid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`usr_id`, `usr_name`, `usr_email`, `usr_mobile`, `usr_clid`, `usr_crsid`) VALUES
(1, 'Usert ', 'us@mail.com', '85745856985', 2, 2),
(2, 'Sagar Rajput', 'sagarraj64742@gmail.com', '08650011462', 2, 1),
(3, 'Sagar Rajput', 'sagarraj64742@gmail.com', '08650011462', 2, 1),
(4, 'Sagar Rajput', 'sagarraj64742@gmail.com', '08650011462', 2, 1),
(5, 'Sagar Rajput', 'sagarraj64742@gmail.com', '08650011462', 2, 1),
(6, 'Sagar Rajput', 'sagarraj64742@gmail.com', '08650011462', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `college`
--
ALTER TABLE `college`
  ADD PRIMARY KEY (`College_Id`);

--
-- Indexes for table `college_course`
--
ALTER TABLE `college_course`
  ADD PRIMARY KEY (`ccrs_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`Course_Id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`usr_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `college_course`
--
ALTER TABLE `college_course`
  MODIFY `ccrs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `usr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
