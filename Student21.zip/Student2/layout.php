<?php 
	session_start();
	error_reporting(0);
	include("config/config.inc.php");
	include("include/common.php");
	function page_head()
	{
		?>
			<!DOCTYPE html>
			<html lang="en">
			<head>
				<title>User Interest</title>
				<meta charset="utf-8">
				<meta name="viewport" content="width=device-width, initial-scale=1">
				<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
			</head>
		<?php
	}
	function menu()
	{
		?>
			<div class="container">
				
				<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
				<!-- Brand -->
					<!-- <a class="navbar-brand" href="index.php">Food Shala</a> -->

					<!-- Links -->
					<ul class="navbar-nav">
						<li class="nav-item">
							<a class="nav-link active" href="index.php">Home</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="admin.php">Admin</a>
						</li>
					</ul>
				</nav>
			</div>
		<?php
	}
	function footer()
	{
		?>	
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
		<?php
	}
?>