<?php
	require("layout.php");

	// if(isset($_SESSION["PKUserId"]))
	// {
	// 	if(user_data($_SESSION["PKUserId"],"Type") == "R")
	// 	{
	// 		echo "<script>window.location.href='r_dashboard.php';</script>";
	// 	}
	// }
	page_head();
?>
<body>
	<?php menu();?>
	<div class="container">
		<div class="row">
			<?php
				$q = "SELECT * FROM college";
				$r = db_query($q);
				$i=0;
				while($d = mysqli_fetch_assoc($r))
				{
					$i++;
					?>
						<div class="col col-md-4">
							<div class="card" style="margin: 10px 5px;">
								<div class="card-body">
									<b>College Name :-</b> <?php echo $d["College_Name"];?><br>
									<b>Courses Available :-</b>
									<div class="row">
										<?php
											$q3 = "SELECT ccrs_crsid FROM college_course WHERE ccrs_clid = '".$d["College_Id"]."'";
											$r3 = db_query($q3);
											while($d3 = mysqli_fetch_assoc($r3))
											{
												echo "<div class='col col-md-3'>".course_data($d3["ccrs_crsid"],"Course_Name")."</div>";
											}
										?>
									</div>
									<hr>
									<a href="insert.php?cl_id=<?php echo $d["College_Id"];?>" class="btn btn-sm btn-info">Select</a>
								</div>
							</div>
						</div>
					<?php
				}
			?>
		</div>
	</div>
	<?php footer();?>
</body>
</html>