<?php
	require("layout.php");
	page_head();
?>
<body>
	<?php menu();?>
	<div class="container">
		<div class="row">
			<div class="col col-md-6">
				<table class="table table-bordered">
					<tr>
						<th>Sr. No.</th>
						<th>College Name</th>
						<th>Course</th>
					</tr>
					<tbody>
						<?php
							$q = "SELECT * FROM college";
							$r = db_query($q);
							$i=0;
							while($d = mysqli_fetch_assoc($r))
							{
								$i++;
								?>
									<tr>
										<td><?php echo $i;?></td>
										<td><?php echo $d["College_Name"];?></td>
										<td>
											<a href="add_course.php?cl_id=<?php echo $d['College_Id'];?>">
												Manage 
												<?php 
													$q1 = "SELECT ccrs_id FROM college_course WHERE ccrs_clid = '".$d["College_Id"]."'";
													$r1 = db_query($q1);
													echo mysqli_num_rows($r1);
												?>
											</a>
										</td>
									</tr>
								<?php
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<?php footer();?>
</body>
</html>