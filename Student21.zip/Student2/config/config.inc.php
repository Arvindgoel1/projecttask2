<?php
    function db_connect() {
        static $connection;
        if(!isset($connection)) 
        {
            $DBServer = 'localhost';
			$DBUser   = 'root';
			$DBPass   = '';
			$DBName   = 'student1';
            $connection = mysqli_connect($DBServer, $DBUser, $DBPass, $DBName);
        }
        if($connection === false) {
            return mysqli_connect_error();
        }
        return $connection;
    }
	
	function db_query($query) 
	{
        $connection = db_connect();

        // Query the database
		$result = mysqli_query($connection,"SET time_zone = '+5:30'");
        $result = mysqli_query($connection,$query);

        return $result;
    }
?>