<?php
	require("layout.php");
	page_head();
	if(isset($_REQUEST["submit"]))
	{
		$q1 = "DELETE FROM college_course WHERE ccrs_clid = '".$_REQUEST["crss_clid"]."'";
		$r1 = db_query($q1);

		foreach($_REQUEST as $key => $value)
		{
			if(substr($key,0,10) == "ccrs_crsid")
			{
				$q2 = "INSERT INTO `college_course`(`ccrs_clid`, `ccrs_crsid`) VALUES ('".$_REQUEST["ccrs_clid"]."','".$value."')";
				$r2 = db_query($q2);
			}
		}
		echo "<script>alert('Course update successfully.');window.location.href='admin.php'</script>";
	}
?>
<body>
	<?php menu();?>
	<div class="container">
		<div class="row">
			<div class="col col-md-6">
				<table class="table table-bordered">
					<tr>
						<th>Sr. No.</th>
						<th>Course Name</th>
						<th>Select</th>
					</tr>
					<tbody>
						<form action="add_course.php" method="post">
							<?php
								$q = "SELECT * FROM course";
								$r = db_query($q);
								$i=0;
								while($d = mysqli_fetch_assoc($r))
								{
									$i++;
									?>
										<tr>
											<td><?php echo $i;?></td>
											<td><?php echo $d["Course_Name"];?></td>
											<td>
												<?php
													$q3 = "SELECT ccrs_id FROM college_course WHERE ccrs_clid = '".$_REQUEST["cl_id"]."' AND ccrs_crsid = '".$d["Course_Id"]."'";
													$nr = mysqli_num_rows(db_query($q3));
												?>
												<label>
													<input <?php if($nr>0){echo "checked";}?> type="checkbox" name="ccrs_crsid~~<?php echo $i;?>" value="<?php echo $d['Course_Id'];?>">
												</label>
											</td>
										</tr>
									<?php
								}
							?>
							<tr>
								<td colspan="3">
									<center>
										<input type="hidden" name="ccrs_clid" value="<?php echo $_REQUEST["cl_id"];?>">
										<input type="submit" name="submit" value="Add Course" class="btn btn-sm btn-success">
									</center>
								</td>
							</tr>
						</form>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<?php footer();?>
</body>
</html>