<?php
  require("layout.php");
  page_head();
if(isset($_POST["submit"]))
{
  
  $nm=$_POST["name"];
  $email=$_POST["email"];
  $mob=$_POST["mob"];
  $course=$_POST["course"];
  $college=$_POST["college"];
  $query2="INSERT INTO `user`(`usr_name`, `usr_email`, `usr_mobile`, `usr_clid`, `usr_crsid`) VALUES('".$nm."','".$email."','".$mob."','".$college."','".$course."')";
  $data2=db_query($query2);
  
  if($data2 == true)
  {
    echo "<script>alert('Thankyou! We will contact you soon.');window.location.href='index.php';</script>";
  }
  else
  {
    echo "<script>alert('Error! Try agian.');window.history.bakc()';</script>";
  }

}/*query3="select * from student";
$data3=mysqli_query($conn,$query3);
echo"<table border=2 cellpading=10 align='center'>";
echo"<tr><th>Name</th><th>Email</th><th>Number</th><th>Course</th><th>College</th></tr>";
$count5=mysqli_num_rows($data2);
echo"<br>Total Number of Records".$count5;
while($row=mysqli_fetch_array($data3))
{
  echo "<tr>";
 
  echo "<td>".$row["name"]."</td>";
  echo "<td>".$row["email"]."</td>";
  echo "<td>".$row["Number"]."</td>";
  echo "<td>".$row["course"]."</td>";
  echo "<td>".$row["college"]."</td>";
  
  echo "</tr>";
  echo "<br>Name=".$row["name"]."<br>";
  echo "<br>Email=".$row["email"]."<br>";
  echo "<br>Number=".$row["Number"]."<br>";
  echo "<br>Course=".$row["course"]."<br>";
  echo "<br>College=".$row["college"]."<br>";
  

}*/


$query="select * from course";
$data=db_query($query);
$query1="select * from college";
$data1=db_query($query1);
?>
<body>

  <?php menu();?>
<div class="container">
  <div class="row">
    <div class="col col-md-6 m-auto">

  <h2>Registration Form</h2>
      <form method="POST" action="insert.php">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="name" class="form-control" id="name" placeholder="Enter Name" name="name">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter Email" name="email">
    </div>
  <div class="form-group">
      <label for="mob">Mobile:</label>
      <input type="text" class="form-control" id="mob" placeholder="Enter Mobile No" name="mob">
    </div>

  <div class="form-group">
      <label>Select College</label>
    <select class="form-control" name="college" id="college">
      <?php while($row=mysqli_fetch_array($data1))
        {
          ?>
            <option <?php if($_REQUEST["cl_id"] == $row["College_Id"]){echo "selected";}?> value="<?php echo $row["College_Id"];?>"><?php echo $row["College_Name"]; ?></option>
          <?php 
        } 
      ?>
    
    </select>
    </div>
    <div class="form-group">
      <label>Select Course</label>
    <select class="form-control" name="course" id="course">
    <?php while($row=mysqli_fetch_array($data)){?>
      <option value="<?php echo $row["Course_Id"]; ?>"><?php echo $row["Course_Name"]; ?></option>
    <?php } ?>
    </select>
    </div>
    <button type="submit" class="btn btn-success btn-sm" name="submit">Submit</button>
    <!-- <a href="display.php"><input type="button" value="show"></a> -->
  </form>
    </div>
  </div>
</div>

  <?php footer();?>
</body>
</html>